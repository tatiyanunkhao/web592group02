<!doctype html>
<?php
 $appid="webproject322236.appspot.com"; 
 $page="home";
 if(isset($_GET['p'])) $page=$_GET['p'];
 if(strpos($page,".")) $page="error";
 $bodyfile = "work7_$page.php";
?>
<html lang="en">
<head>
 <meta charset="UTF-8"><title><?= $page ?></title>
 <link href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css" rel="stylesheet">
</head>
<body background="http://i021.radikal.ru/0804/57/3f9d58ae6b47.jpg">

<body role="document">
<header class="page-header text-center">
<?php
 readfile("gs://$appid/header.html");
?>
</header>
 <div class="container">
 <div class="col-xs-12 col-sm-6 col-md-3" id="menudiv">
<h3> <?php include("work7menu.php"); ?></h3>
<a href="work7.php?p=edit&file=menu.txt" class="btn btn-default"><h4> แก้ไขเมนู</h4> </a>
</div>
<div class=="col-xs-12 col-sm-6 col-md-9" id="bodydiv">
<?php
 if(file_exists($bodyfile)){
include($bodyfile);
 }else {
 echo "<h2>$title</h2>";
 $htmlfile = "gs://$appid/$page.html";
 if(file_exists($htmlfile)){
 readfile($htmlfile);
 }
 echo "<br><a href='work7.php?p=edit&file=$page.html' class='btn btn-default'><h4>Edit</h4></a>";
 }
?>
</div>
</div>
<footer class="text-center page-footer">
<?php
 readfile("gs://$appid/footer.html");
 echo "<br><a href='?p=edit&file=header.html' class='btn btn-default'><h4>แก้ไข header</h4></a>";
 echo "<a href='?p=edit&file=footer.html' class='btn btn-default'><h4>แก้ไข footer</h4></a>";
?>
</footer>
</body></html>